﻿namespace HProgramming
{
    partial class Appointmentform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Appointmentform));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.doctorsnameapptext = new Bunifu.Framework.UI.BunifuDropdown();
            this.pointmentdatepicker = new Bunifu.Framework.UI.BunifuDatepicker();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.patientsbirdatetext = new Bunifu.Framework.UI.BunifuDatepicker();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.firsnametextbox = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.emailtextbox = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.phonenumbertextbox = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.sendappoitment = new Bunifu.Framework.UI.BunifuFlatButton();
            this.cancelappointmentbtn = new Bunifu.Framework.UI.BunifuFlatButton();
            this.userformcontrolpanel = new System.Windows.Forms.Panel();
            this.seetodayappointment = new Bunifu.Framework.UI.BunifuFlatButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.birthofdatepickerappoint = new Bunifu.Framework.UI.BunifuDatepicker();
            this.addresstextbox = new System.Windows.Forms.TextBox();
            this.addres = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.departmentdropdownbtn = new Bunifu.Framework.UI.BunifuDropdown();
            this.timedropbox = new Bunifu.Framework.UI.BunifuDropdown();
            this.appointime = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.sexappoitmentdropbox = new Bunifu.Framework.UI.BunifuDropdown();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lastnametextbox = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.centralappointcontrol = new System.Windows.Forms.Panel();
            this.makenewappointment = new Bunifu.Framework.UI.BunifuFlatButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tomorrowappointment = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.numberappoint = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tomorrowporgresscircle = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.progresscircle = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.searchtextboxapp = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.searchappointmentbtn = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuCustomDataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.numberİdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phonenumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sexDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateofBirthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.departmentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.doctorsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.appointmentdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.appointmenttimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.appointmenttableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hospitalManagmentSystDataSet7 = new HProgramming.HospitalManagmentSystDataSet7();
            this.appointment_tableTableAdapter = new HProgramming.HospitalManagmentSystDataSet7TableAdapters.Appointment_tableTableAdapter();
            this.userformcontrolpanel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.centralappointcontrol.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchappointmentbtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointmenttableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hospitalManagmentSystDataSet7)).BeginInit();
            this.SuspendLayout();
            // 
            // doctorsnameapptext
            // 
            this.doctorsnameapptext.BackColor = System.Drawing.Color.Transparent;
            this.doctorsnameapptext.BorderRadius = 3;
            this.doctorsnameapptext.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.doctorsnameapptext.ForeColor = System.Drawing.Color.White;
            this.doctorsnameapptext.Items = new string[] {
        "Dr. Zengin",
        "Pr .Dr Alpha",
        "Dr. Beta",
        "Dr. Gama",
        "Dr .Teta",
        "Dr.Sigma"};
            this.doctorsnameapptext.Location = new System.Drawing.Point(573, 98);
            this.doctorsnameapptext.Margin = new System.Windows.Forms.Padding(4);
            this.doctorsnameapptext.Name = "doctorsnameapptext";
            this.doctorsnameapptext.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.doctorsnameapptext.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.doctorsnameapptext.selectedIndex = -1;
            this.doctorsnameapptext.Size = new System.Drawing.Size(241, 36);
            this.doctorsnameapptext.TabIndex = 2;
            this.doctorsnameapptext.onItemSelected += new System.EventHandler(this.doctorsnameapptext_onItemSelected);
            // 
            // pointmentdatepicker
            // 
            this.pointmentdatepicker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.pointmentdatepicker.BorderRadius = 0;
            this.pointmentdatepicker.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pointmentdatepicker.ForeColor = System.Drawing.Color.White;
            this.pointmentdatepicker.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.pointmentdatepicker.FormatCustom = null;
            this.pointmentdatepicker.Location = new System.Drawing.Point(575, 177);
            this.pointmentdatepicker.Margin = new System.Windows.Forms.Padding(4);
            this.pointmentdatepicker.Name = "pointmentdatepicker";
            this.pointmentdatepicker.Size = new System.Drawing.Size(241, 46);
            this.pointmentdatepicker.TabIndex = 3;
            this.pointmentdatepicker.Value = new System.DateTime(2020, 5, 8, 17, 23, 34, 0);
            this.pointmentdatepicker.onValueChanged += new System.EventHandler(this.appointmentdatepicker_onValueChanged);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(6, 99);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(89, 18);
            this.bunifuCustomLabel1.TabIndex = 6;
            this.bunifuCustomLabel1.Text = "Lastname   :";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(6, 33);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(86, 18);
            this.bunifuCustomLabel2.TabIndex = 6;
            this.bunifuCustomLabel2.Text = "Firstname  :";
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(11, 324);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(81, 18);
            this.bunifuCustomLabel3.TabIndex = 6;
            this.bunifuCustomLabel3.Text = "Sex           :";
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(427, 28);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(94, 18);
            this.bunifuCustomLabel4.TabIndex = 6;
            this.bunifuCustomLabel4.Text = "Date of Birth:";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(427, 186);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(129, 18);
            this.bunifuCustomLabel5.TabIndex = 6;
            this.bunifuCustomLabel5.Text = "Appointment Date:";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(427, 109);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(129, 18);
            this.bunifuCustomLabel6.TabIndex = 6;
            this.bunifuCustomLabel6.Text = "Doctor\'s Name    :";
            // 
            // patientsbirdatetext
            // 
            this.patientsbirdatetext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.patientsbirdatetext.BorderRadius = 0;
            this.patientsbirdatetext.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.patientsbirdatetext.ForeColor = System.Drawing.Color.White;
            this.patientsbirdatetext.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.patientsbirdatetext.FormatCustom = "";
            this.patientsbirdatetext.Location = new System.Drawing.Point(185, 473);
            this.patientsbirdatetext.Margin = new System.Windows.Forms.Padding(4);
            this.patientsbirdatetext.Name = "patientsbirdatetext";
            this.patientsbirdatetext.Size = new System.Drawing.Size(257, 46);
            this.patientsbirdatetext.TabIndex = 3;
            this.patientsbirdatetext.Value = new System.DateTime(2020, 5, 8, 17, 22, 45, 0);
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("RomanT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(243, 9);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(354, 39);
            this.bunifuCustomLabel7.TabIndex = 8;
            this.bunifuCustomLabel7.Text = "Appointment Maker";
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(10, 177);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(85, 18);
            this.bunifuCustomLabel8.TabIndex = 9;
            this.bunifuCustomLabel8.Text = "Email         :";
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(6, 236);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(112, 18);
            this.bunifuCustomLabel9.TabIndex = 9;
            this.bunifuCustomLabel9.Text = "Phone Number:";
            // 
            // firsnametextbox
            // 
            this.firsnametextbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.firsnametextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.firsnametextbox.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.firsnametextbox.ForeColor = System.Drawing.Color.White;
            this.firsnametextbox.HintForeColor = System.Drawing.Color.White;
            this.firsnametextbox.HintText = "";
            this.firsnametextbox.isPassword = false;
            this.firsnametextbox.LineFocusedColor = System.Drawing.Color.Blue;
            this.firsnametextbox.LineIdleColor = System.Drawing.Color.Gray;
            this.firsnametextbox.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.firsnametextbox.LineThickness = 3;
            this.firsnametextbox.Location = new System.Drawing.Point(139, 20);
            this.firsnametextbox.Margin = new System.Windows.Forms.Padding(4);
            this.firsnametextbox.Name = "firsnametextbox";
            this.firsnametextbox.Size = new System.Drawing.Size(194, 44);
            this.firsnametextbox.TabIndex = 10;
            this.firsnametextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.firsnametextbox.OnValueChanged += new System.EventHandler(this.firsnametextbox_OnValueChanged);
            // 
            // emailtextbox
            // 
            this.emailtextbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.emailtextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.emailtextbox.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.emailtextbox.ForeColor = System.Drawing.Color.White;
            this.emailtextbox.HintForeColor = System.Drawing.Color.White;
            this.emailtextbox.HintText = "";
            this.emailtextbox.isPassword = false;
            this.emailtextbox.LineFocusedColor = System.Drawing.Color.Blue;
            this.emailtextbox.LineIdleColor = System.Drawing.Color.Gray;
            this.emailtextbox.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.emailtextbox.LineThickness = 3;
            this.emailtextbox.Location = new System.Drawing.Point(139, 160);
            this.emailtextbox.Margin = new System.Windows.Forms.Padding(4);
            this.emailtextbox.Name = "emailtextbox";
            this.emailtextbox.Size = new System.Drawing.Size(194, 44);
            this.emailtextbox.TabIndex = 10;
            this.emailtextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.emailtextbox.OnValueChanged += new System.EventHandler(this.emailtextbox_OnValueChanged);
            // 
            // phonenumbertextbox
            // 
            this.phonenumbertextbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.phonenumbertextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.phonenumbertextbox.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.phonenumbertextbox.ForeColor = System.Drawing.Color.White;
            this.phonenumbertextbox.HintForeColor = System.Drawing.Color.White;
            this.phonenumbertextbox.HintText = "";
            this.phonenumbertextbox.isPassword = false;
            this.phonenumbertextbox.LineFocusedColor = System.Drawing.Color.Blue;
            this.phonenumbertextbox.LineIdleColor = System.Drawing.Color.Gray;
            this.phonenumbertextbox.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.phonenumbertextbox.LineThickness = 3;
            this.phonenumbertextbox.Location = new System.Drawing.Point(139, 226);
            this.phonenumbertextbox.Margin = new System.Windows.Forms.Padding(4);
            this.phonenumbertextbox.Name = "phonenumbertextbox";
            this.phonenumbertextbox.Size = new System.Drawing.Size(194, 42);
            this.phonenumbertextbox.TabIndex = 10;
            this.phonenumbertextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.phonenumbertextbox.OnValueChanged += new System.EventHandler(this.phonenumbertextbox_OnValueChanged);
            // 
            // sendappoitment
            // 
            this.sendappoitment.Activecolor = System.Drawing.Color.Teal;
            this.sendappoitment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.sendappoitment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sendappoitment.BorderRadius = 0;
            this.sendappoitment.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.sendappoitment.ButtonText = "Send";
            this.sendappoitment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sendappoitment.DisabledColor = System.Drawing.Color.Gray;
            this.sendappoitment.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.sendappoitment.Iconcolor = System.Drawing.Color.Transparent;
            this.sendappoitment.Iconimage = ((System.Drawing.Image)(resources.GetObject("sendappoitment.Iconimage")));
            this.sendappoitment.Iconimage_right = null;
            this.sendappoitment.Iconimage_right_Selected = null;
            this.sendappoitment.Iconimage_Selected = null;
            this.sendappoitment.IconMarginLeft = 0;
            this.sendappoitment.IconMarginRight = 0;
            this.sendappoitment.IconRightVisible = true;
            this.sendappoitment.IconRightZoom = 0D;
            this.sendappoitment.IconVisible = true;
            this.sendappoitment.IconZoom = 90D;
            this.sendappoitment.IsTab = false;
            this.sendappoitment.Location = new System.Drawing.Point(636, 497);
            this.sendappoitment.Name = "sendappoitment";
            this.sendappoitment.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.sendappoitment.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.sendappoitment.OnHoverTextColor = System.Drawing.Color.White;
            this.sendappoitment.selected = false;
            this.sendappoitment.Size = new System.Drawing.Size(92, 48);
            this.sendappoitment.TabIndex = 11;
            this.sendappoitment.Text = "Send";
            this.sendappoitment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sendappoitment.Textcolor = System.Drawing.Color.White;
            this.sendappoitment.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sendappoitment.Click += new System.EventHandler(this.appoitementsender_Click);
            // 
            // cancelappointmentbtn
            // 
            this.cancelappointmentbtn.Activecolor = System.Drawing.Color.Teal;
            this.cancelappointmentbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.cancelappointmentbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cancelappointmentbtn.BorderRadius = 0;
            this.cancelappointmentbtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.cancelappointmentbtn.ButtonText = "Cancel";
            this.cancelappointmentbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancelappointmentbtn.DisabledColor = System.Drawing.Color.Gray;
            this.cancelappointmentbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cancelappointmentbtn.Iconcolor = System.Drawing.Color.Transparent;
            this.cancelappointmentbtn.Iconimage = ((System.Drawing.Image)(resources.GetObject("cancelappointmentbtn.Iconimage")));
            this.cancelappointmentbtn.Iconimage_right = null;
            this.cancelappointmentbtn.Iconimage_right_Selected = null;
            this.cancelappointmentbtn.Iconimage_Selected = null;
            this.cancelappointmentbtn.IconMarginLeft = 0;
            this.cancelappointmentbtn.IconMarginRight = 0;
            this.cancelappointmentbtn.IconRightVisible = true;
            this.cancelappointmentbtn.IconRightZoom = 0D;
            this.cancelappointmentbtn.IconVisible = true;
            this.cancelappointmentbtn.IconZoom = 90D;
            this.cancelappointmentbtn.IsTab = false;
            this.cancelappointmentbtn.Location = new System.Drawing.Point(749, 497);
            this.cancelappointmentbtn.Name = "cancelappointmentbtn";
            this.cancelappointmentbtn.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.cancelappointmentbtn.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.cancelappointmentbtn.OnHoverTextColor = System.Drawing.Color.White;
            this.cancelappointmentbtn.selected = false;
            this.cancelappointmentbtn.Size = new System.Drawing.Size(103, 48);
            this.cancelappointmentbtn.TabIndex = 11;
            this.cancelappointmentbtn.Text = "Cancel";
            this.cancelappointmentbtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancelappointmentbtn.Textcolor = System.Drawing.Color.White;
            this.cancelappointmentbtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelappointmentbtn.Click += new System.EventHandler(this.cancelappointmentbtn_Click);
            // 
            // userformcontrolpanel
            // 
            this.userformcontrolpanel.Controls.Add(this.centralappointcontrol);
            this.userformcontrolpanel.Controls.Add(this.seetodayappointment);
            this.userformcontrolpanel.Controls.Add(this.groupBox1);
            this.userformcontrolpanel.Controls.Add(this.bunifuCustomLabel7);
            this.userformcontrolpanel.Controls.Add(this.cancelappointmentbtn);
            this.userformcontrolpanel.Controls.Add(this.sendappoitment);
            this.userformcontrolpanel.Location = new System.Drawing.Point(3, 35);
            this.userformcontrolpanel.Name = "userformcontrolpanel";
            this.userformcontrolpanel.Size = new System.Drawing.Size(868, 548);
            this.userformcontrolpanel.TabIndex = 12;
            // 
            // seetodayappointment
            // 
            this.seetodayappointment.Activecolor = System.Drawing.Color.Teal;
            this.seetodayappointment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.seetodayappointment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.seetodayappointment.BorderRadius = 0;
            this.seetodayappointment.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.seetodayappointment.ButtonText = "See Today\'s Appointments";
            this.seetodayappointment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.seetodayappointment.DisabledColor = System.Drawing.Color.Gray;
            this.seetodayappointment.Iconcolor = System.Drawing.Color.Transparent;
            this.seetodayappointment.Iconimage = ((System.Drawing.Image)(resources.GetObject("seetodayappointment.Iconimage")));
            this.seetodayappointment.Iconimage_right = null;
            this.seetodayappointment.Iconimage_right_Selected = null;
            this.seetodayappointment.Iconimage_Selected = null;
            this.seetodayappointment.IconMarginLeft = 0;
            this.seetodayappointment.IconMarginRight = 0;
            this.seetodayappointment.IconRightVisible = true;
            this.seetodayappointment.IconRightZoom = 0D;
            this.seetodayappointment.IconVisible = true;
            this.seetodayappointment.IconZoom = 90D;
            this.seetodayappointment.IsTab = false;
            this.seetodayappointment.Location = new System.Drawing.Point(704, 3);
            this.seetodayappointment.Name = "seetodayappointment";
            this.seetodayappointment.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.seetodayappointment.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.seetodayappointment.OnHoverTextColor = System.Drawing.Color.White;
            this.seetodayappointment.selected = false;
            this.seetodayappointment.Size = new System.Drawing.Size(148, 48);
            this.seetodayappointment.TabIndex = 25;
            this.seetodayappointment.Text = "See Today\'s Appointments";
            this.seetodayappointment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.seetodayappointment.Textcolor = System.Drawing.Color.White;
            this.seetodayappointment.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seetodayappointment.Click += new System.EventHandler(this.seetodayappointment_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.birthofdatepickerappoint);
            this.groupBox1.Controls.Add(this.addresstextbox);
            this.groupBox1.Controls.Add(this.addres);
            this.groupBox1.Controls.Add(this.firsnametextbox);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel2);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.emailtextbox);
            this.groupBox1.Controls.Add(this.departmentdropdownbtn);
            this.groupBox1.Controls.Add(this.timedropbox);
            this.groupBox1.Controls.Add(this.appointime);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.sexappoitmentdropbox);
            this.groupBox1.Controls.Add(this.doctorsnameapptext);
            this.groupBox1.Controls.Add(this.pointmentdatepicker);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel3);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel4);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.patientsbirdatetext);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel5);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel6);
            this.groupBox1.Controls.Add(this.phonenumbertextbox);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel8);
            this.groupBox1.Controls.Add(this.lastnametextbox);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel9);
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox1.Location = new System.Drawing.Point(3, 51);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(849, 443);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Appointment Format";
            // 
            // birthofdatepickerappoint
            // 
            this.birthofdatepickerappoint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.birthofdatepickerappoint.BorderRadius = 0;
            this.birthofdatepickerappoint.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.birthofdatepickerappoint.ForeColor = System.Drawing.Color.White;
            this.birthofdatepickerappoint.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.birthofdatepickerappoint.FormatCustom = null;
            this.birthofdatepickerappoint.Location = new System.Drawing.Point(575, 19);
            this.birthofdatepickerappoint.Name = "birthofdatepickerappoint";
            this.birthofdatepickerappoint.Size = new System.Drawing.Size(242, 41);
            this.birthofdatepickerappoint.TabIndex = 26;
            this.birthofdatepickerappoint.Value = new System.DateTime(2020, 5, 12, 0, 26, 55, 917);
            this.birthofdatepickerappoint.onValueChanged += new System.EventHandler(this.birthofdatepickerappoint_onValueChanged);
            // 
            // addresstextbox
            // 
            this.addresstextbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.addresstextbox.ForeColor = System.Drawing.SystemColors.Info;
            this.addresstextbox.Location = new System.Drawing.Point(577, 328);
            this.addresstextbox.Multiline = true;
            this.addresstextbox.Name = "addresstextbox";
            this.addresstextbox.Size = new System.Drawing.Size(240, 98);
            this.addresstextbox.TabIndex = 25;
            this.addresstextbox.TextChanged += new System.EventHandler(this.addresstextbox_TextChanged);
            // 
            // addres
            // 
            this.addres.AutoSize = true;
            this.addres.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.addres.Location = new System.Drawing.Point(427, 384);
            this.addres.Name = "addres";
            this.addres.Size = new System.Drawing.Size(66, 18);
            this.addres.TabIndex = 24;
            this.addres.Text = "Address:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(823, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 25);
            this.label7.TabIndex = 23;
            this.label7.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(823, 109);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 25);
            this.label8.TabIndex = 23;
            this.label8.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(823, 317);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(20, 25);
            this.label9.TabIndex = 23;
            this.label9.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(340, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(20, 25);
            this.label10.TabIndex = 23;
            this.label10.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(340, 377);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 25);
            this.label11.TabIndex = 23;
            this.label11.Text = "*";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(340, 143);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 25);
            this.label2.TabIndex = 23;
            this.label2.Text = "*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(340, 302);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 25);
            this.label6.TabIndex = 23;
            this.label6.Text = "*";
            // 
            // departmentdropdownbtn
            // 
            this.departmentdropdownbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.departmentdropdownbtn.BorderRadius = 3;
            this.departmentdropdownbtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.departmentdropdownbtn.ForeColor = System.Drawing.Color.White;
            this.departmentdropdownbtn.Items = new string[] {
        "Only Consultation",
        "Oncology",
        "Neurology",
        "İnfections Diseases",
        "Hematology",
        "Chirurgy",
        "Toxicology"};
            this.departmentdropdownbtn.Location = new System.Drawing.Point(139, 384);
            this.departmentdropdownbtn.Margin = new System.Windows.Forms.Padding(4);
            this.departmentdropdownbtn.Name = "departmentdropdownbtn";
            this.departmentdropdownbtn.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.departmentdropdownbtn.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.departmentdropdownbtn.selectedIndex = -1;
            this.departmentdropdownbtn.Size = new System.Drawing.Size(194, 42);
            this.departmentdropdownbtn.TabIndex = 20;
            this.departmentdropdownbtn.onItemSelected += new System.EventHandler(this.departmentdropdownbtn_onItemSelected);
            // 
            // timedropbox
            // 
            this.timedropbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.timedropbox.BorderRadius = 3;
            this.timedropbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.timedropbox.ForeColor = System.Drawing.Color.White;
            this.timedropbox.Items = new string[] {
        "8:00 AM",
        "8:30 AM",
        "9:00 AM",
        "9:30 AM",
        "10:00 AM",
        "10:30 AM",
        "11:00 AM",
        "11:30 AM",
        "13:00 PM",
        "13:30 PM",
        "14:00 PM",
        "14:30 PM",
        "15:00 PM",
        "15:30 PM",
        "16:00 PM",
        "16:30 PM",
        ""};
            this.timedropbox.Location = new System.Drawing.Point(575, 251);
            this.timedropbox.Margin = new System.Windows.Forms.Padding(4);
            this.timedropbox.Name = "timedropbox";
            this.timedropbox.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.timedropbox.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.timedropbox.selectedIndex = -1;
            this.timedropbox.Size = new System.Drawing.Size(239, 42);
            this.timedropbox.TabIndex = 20;
            this.timedropbox.onItemSelected += new System.EventHandler(this.timedropbox_onItemSelected);
            // 
            // appointime
            // 
            this.appointime.AutoSize = true;
            this.appointime.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.appointime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.appointime.Location = new System.Drawing.Point(427, 260);
            this.appointime.Name = "appointime";
            this.appointime.Size = new System.Drawing.Size(131, 18);
            this.appointime.TabIndex = 21;
            this.appointime.Text = "Appointment Time:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(823, 226);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(20, 25);
            this.label12.TabIndex = 23;
            this.label12.Text = "*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(823, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 25);
            this.label5.TabIndex = 23;
            this.label5.Text = "*";
            // 
            // sexappoitmentdropbox
            // 
            this.sexappoitmentdropbox.BackColor = System.Drawing.Color.Transparent;
            this.sexappoitmentdropbox.BorderRadius = 3;
            this.sexappoitmentdropbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.sexappoitmentdropbox.ForeColor = System.Drawing.Color.White;
            this.sexappoitmentdropbox.Items = new string[] {
        "Male",
        "Female",
        "Others"};
            this.sexappoitmentdropbox.Location = new System.Drawing.Point(139, 306);
            this.sexappoitmentdropbox.Margin = new System.Windows.Forms.Padding(4);
            this.sexappoitmentdropbox.Name = "sexappoitmentdropbox";
            this.sexappoitmentdropbox.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.sexappoitmentdropbox.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.sexappoitmentdropbox.selectedIndex = -1;
            this.sexappoitmentdropbox.Size = new System.Drawing.Size(194, 36);
            this.sexappoitmentdropbox.TabIndex = 2;
            this.sexappoitmentdropbox.onItemSelected += new System.EventHandler(this.sexappoitmentdropbox_onItemSelected);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(11, 396);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 18);
            this.label1.TabIndex = 19;
            this.label1.Text = "Department          :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(340, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 25);
            this.label3.TabIndex = 23;
            this.label3.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(340, 208);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 25);
            this.label4.TabIndex = 23;
            this.label4.Text = "*";
            // 
            // lastnametextbox
            // 
            this.lastnametextbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lastnametextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.lastnametextbox.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.lastnametextbox.ForeColor = System.Drawing.Color.White;
            this.lastnametextbox.HintForeColor = System.Drawing.Color.White;
            this.lastnametextbox.HintText = "";
            this.lastnametextbox.isPassword = false;
            this.lastnametextbox.LineFocusedColor = System.Drawing.Color.Blue;
            this.lastnametextbox.LineIdleColor = System.Drawing.Color.Gray;
            this.lastnametextbox.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.lastnametextbox.LineThickness = 3;
            this.lastnametextbox.Location = new System.Drawing.Point(139, 90);
            this.lastnametextbox.Margin = new System.Windows.Forms.Padding(4);
            this.lastnametextbox.Name = "lastnametextbox";
            this.lastnametextbox.Size = new System.Drawing.Size(194, 44);
            this.lastnametextbox.TabIndex = 13;
            this.lastnametextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.lastnametextbox.OnValueChanged += new System.EventHandler(this.lastnametextbox_OnValueChanged);
            // 
            // centralappointcontrol
            // 
            this.centralappointcontrol.Controls.Add(this.makenewappointment);
            this.centralappointcontrol.Controls.Add(this.groupBox3);
            this.centralappointcontrol.Controls.Add(this.groupBox2);
            this.centralappointcontrol.Dock = System.Windows.Forms.DockStyle.Fill;
            this.centralappointcontrol.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.centralappointcontrol.Location = new System.Drawing.Point(0, 0);
            this.centralappointcontrol.Name = "centralappointcontrol";
            this.centralappointcontrol.Size = new System.Drawing.Size(868, 548);
            this.centralappointcontrol.TabIndex = 26;
            // 
            // makenewappointment
            // 
            this.makenewappointment.Activecolor = System.Drawing.Color.Teal;
            this.makenewappointment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.makenewappointment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.makenewappointment.BorderRadius = 0;
            this.makenewappointment.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.makenewappointment.ButtonText = "Make New Appointment";
            this.makenewappointment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.makenewappointment.DisabledColor = System.Drawing.Color.Gray;
            this.makenewappointment.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.makenewappointment.Iconcolor = System.Drawing.Color.Transparent;
            this.makenewappointment.Iconimage = ((System.Drawing.Image)(resources.GetObject("makenewappointment.Iconimage")));
            this.makenewappointment.Iconimage_right = null;
            this.makenewappointment.Iconimage_right_Selected = null;
            this.makenewappointment.Iconimage_Selected = null;
            this.makenewappointment.IconMarginLeft = 0;
            this.makenewappointment.IconMarginRight = 0;
            this.makenewappointment.IconRightVisible = true;
            this.makenewappointment.IconRightZoom = 0D;
            this.makenewappointment.IconVisible = true;
            this.makenewappointment.IconZoom = 90D;
            this.makenewappointment.IsTab = false;
            this.makenewappointment.Location = new System.Drawing.Point(711, 352);
            this.makenewappointment.Name = "makenewappointment";
            this.makenewappointment.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.makenewappointment.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.makenewappointment.OnHoverTextColor = System.Drawing.Color.White;
            this.makenewappointment.selected = false;
            this.makenewappointment.Size = new System.Drawing.Size(154, 53);
            this.makenewappointment.TabIndex = 2;
            this.makenewappointment.Text = "Make New Appointment";
            this.makenewappointment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.makenewappointment.Textcolor = System.Drawing.Color.White;
            this.makenewappointment.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.makenewappointment.Click += new System.EventHandler(this.makenewappointment_Click_1);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pictureBox3);
            this.groupBox3.Controls.Add(this.pictureBox2);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel11);
            this.groupBox3.Controls.Add(this.bunifuCustomLabel10);
            this.groupBox3.Controls.Add(this.tomorrowappointment);
            this.groupBox3.Controls.Add(this.numberappoint);
            this.groupBox3.Controls.Add(this.tomorrowporgresscircle);
            this.groupBox3.Controls.Add(this.progresscircle);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox3.Location = new System.Drawing.Point(3, 405);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(862, 160);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Day Appointment";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(756, 8);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(46, 41);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(330, 8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(46, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(529, 24);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(221, 16);
            this.bunifuCustomLabel11.TabIndex = 1;
            this.bunifuCustomLabel11.Text = "Available Appointment of Tomorrow";
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(116, 24);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(208, 16);
            this.bunifuCustomLabel10.TabIndex = 1;
            this.bunifuCustomLabel10.Text = "Available Appointment of this Day";
            // 
            // tomorrowappointment
            // 
            this.tomorrowappointment.AutoSize = true;
            this.tomorrowappointment.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tomorrowappointment.Location = new System.Drawing.Point(679, 74);
            this.tomorrowappointment.Name = "tomorrowappointment";
            this.tomorrowappointment.Size = new System.Drawing.Size(22, 24);
            this.tomorrowappointment.TabIndex = 1;
            this.tomorrowappointment.Text = "B";
            // 
            // numberappoint
            // 
            this.numberappoint.AutoSize = true;
            this.numberappoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.numberappoint.Location = new System.Drawing.Point(203, 74);
            this.numberappoint.Name = "numberappoint";
            this.numberappoint.Size = new System.Drawing.Size(23, 24);
            this.numberappoint.TabIndex = 1;
            this.numberappoint.Text = "A";
            // 
            // tomorrowporgresscircle
            // 
            this.tomorrowporgresscircle.animated = true;
            this.tomorrowporgresscircle.animationIterval = 5;
            this.tomorrowporgresscircle.animationSpeed = 300;
            this.tomorrowporgresscircle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.tomorrowporgresscircle.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tomorrowporgresscircle.BackgroundImage")));
            this.tomorrowporgresscircle.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F);
            this.tomorrowporgresscircle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tomorrowporgresscircle.LabelVisible = false;
            this.tomorrowporgresscircle.LineProgressThickness = 5;
            this.tomorrowporgresscircle.LineThickness = 3;
            this.tomorrowporgresscircle.Location = new System.Drawing.Point(654, 49);
            this.tomorrowporgresscircle.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.tomorrowporgresscircle.MaxValue = 100;
            this.tomorrowporgresscircle.Name = "tomorrowporgresscircle";
            this.tomorrowporgresscircle.ProgressBackColor = System.Drawing.Color.Gainsboro;
            this.tomorrowporgresscircle.ProgressColor = System.Drawing.Color.Lime;
            this.tomorrowporgresscircle.Size = new System.Drawing.Size(71, 71);
            this.tomorrowporgresscircle.TabIndex = 0;
            this.tomorrowporgresscircle.Value = 5;
            // 
            // progresscircle
            // 
            this.progresscircle.animated = true;
            this.progresscircle.animationIterval = 5;
            this.progresscircle.animationSpeed = 300;
            this.progresscircle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.progresscircle.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("progresscircle.BackgroundImage")));
            this.progresscircle.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F);
            this.progresscircle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.progresscircle.LabelVisible = false;
            this.progresscircle.LineProgressThickness = 5;
            this.progresscircle.LineThickness = 3;
            this.progresscircle.Location = new System.Drawing.Point(175, 49);
            this.progresscircle.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.progresscircle.MaxValue = 100;
            this.progresscircle.Name = "progresscircle";
            this.progresscircle.ProgressBackColor = System.Drawing.Color.Gainsboro;
            this.progresscircle.ProgressColor = System.Drawing.Color.Lime;
            this.progresscircle.Size = new System.Drawing.Size(71, 71);
            this.progresscircle.TabIndex = 0;
            this.progresscircle.Value = 5;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.searchtextboxapp);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.searchappointmentbtn);
            this.groupBox2.Controls.Add(this.bunifuCustomDataGrid1);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.ForeColor = System.Drawing.Color.Teal;
            this.groupBox2.Location = new System.Drawing.Point(6, 46);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(859, 300);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "All Appointment View";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label13.Location = new System.Drawing.Point(64, 262);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(159, 16);
            this.label13.TabIndex = 5;
            this.label13.Text = "Search only by Firstname";
            // 
            // searchtextboxapp
            // 
            this.searchtextboxapp.BorderColorFocused = System.Drawing.Color.SlateGray;
            this.searchtextboxapp.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.searchtextboxapp.BorderColorMouseHover = System.Drawing.Color.Teal;
            this.searchtextboxapp.BorderThickness = 3;
            this.searchtextboxapp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.searchtextboxapp.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.searchtextboxapp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.searchtextboxapp.isPassword = false;
            this.searchtextboxapp.Location = new System.Drawing.Point(417, 18);
            this.searchtextboxapp.Margin = new System.Windows.Forms.Padding(4);
            this.searchtextboxapp.Name = "searchtextboxapp";
            this.searchtextboxapp.Size = new System.Drawing.Size(332, 44);
            this.searchtextboxapp.TabIndex = 4;
            this.searchtextboxapp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 256);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(44, 28);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // searchappointmentbtn
            // 
            this.searchappointmentbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.searchappointmentbtn.Image = ((System.Drawing.Image)(resources.GetObject("searchappointmentbtn.Image")));
            this.searchappointmentbtn.ImageActive = null;
            this.searchappointmentbtn.Location = new System.Drawing.Point(777, 18);
            this.searchappointmentbtn.Name = "searchappointmentbtn";
            this.searchappointmentbtn.Size = new System.Drawing.Size(61, 44);
            this.searchappointmentbtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.searchappointmentbtn.TabIndex = 2;
            this.searchappointmentbtn.TabStop = false;
            this.searchappointmentbtn.Zoom = 10;
            this.searchappointmentbtn.Click += new System.EventHandler(this.searchappointmentbtn_Click);
            // 
            // bunifuCustomDataGrid1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuCustomDataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.bunifuCustomDataGrid1.AutoGenerateColumns = false;
            this.bunifuCustomDataGrid1.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuCustomDataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Lime;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuCustomDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.bunifuCustomDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bunifuCustomDataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numberİdDataGridViewTextBoxColumn,
            this.firstnameDataGridViewTextBoxColumn,
            this.lastnameDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.phonenumberDataGridViewTextBoxColumn,
            this.sexDataGridViewTextBoxColumn,
            this.dateofBirthDataGridViewTextBoxColumn,
            this.departmentDataGridViewTextBoxColumn,
            this.doctorsnameDataGridViewTextBoxColumn,
            this.appointmentdateDataGridViewTextBoxColumn,
            this.appointmenttimeDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn});
            this.bunifuCustomDataGrid1.DataSource = this.appointmenttableBindingSource;
            this.bunifuCustomDataGrid1.DoubleBuffered = true;
            this.bunifuCustomDataGrid1.EnableHeadersVisualStyles = false;
            this.bunifuCustomDataGrid1.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bunifuCustomDataGrid1.HeaderBgColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.bunifuCustomDataGrid1.HeaderForeColor = System.Drawing.Color.Lime;
            this.bunifuCustomDataGrid1.Location = new System.Drawing.Point(4, 81);
            this.bunifuCustomDataGrid1.Name = "bunifuCustomDataGrid1";
            this.bunifuCustomDataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Teal;
            this.bunifuCustomDataGrid1.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.bunifuCustomDataGrid1.Size = new System.Drawing.Size(849, 164);
            this.bunifuCustomDataGrid1.TabIndex = 0;
            this.bunifuCustomDataGrid1.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.bunifuCustomDataGrid1_CellFormatting);
            this.bunifuCustomDataGrid1.CellStyleChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.bunifuCustomDataGrid1_CellStyleChanged);
            // 
            // numberİdDataGridViewTextBoxColumn
            // 
            this.numberİdDataGridViewTextBoxColumn.DataPropertyName = "Numberİd";
            this.numberİdDataGridViewTextBoxColumn.HeaderText = "Numberİd";
            this.numberİdDataGridViewTextBoxColumn.Name = "numberİdDataGridViewTextBoxColumn";
            this.numberİdDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // firstnameDataGridViewTextBoxColumn
            // 
            this.firstnameDataGridViewTextBoxColumn.DataPropertyName = "Firstname";
            this.firstnameDataGridViewTextBoxColumn.HeaderText = "Firstname";
            this.firstnameDataGridViewTextBoxColumn.Name = "firstnameDataGridViewTextBoxColumn";
            // 
            // lastnameDataGridViewTextBoxColumn
            // 
            this.lastnameDataGridViewTextBoxColumn.DataPropertyName = "Lastname";
            this.lastnameDataGridViewTextBoxColumn.HeaderText = "Lastname";
            this.lastnameDataGridViewTextBoxColumn.Name = "lastnameDataGridViewTextBoxColumn";
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            // 
            // phonenumberDataGridViewTextBoxColumn
            // 
            this.phonenumberDataGridViewTextBoxColumn.DataPropertyName = "Phone_number";
            this.phonenumberDataGridViewTextBoxColumn.HeaderText = "Phone_number";
            this.phonenumberDataGridViewTextBoxColumn.Name = "phonenumberDataGridViewTextBoxColumn";
            // 
            // sexDataGridViewTextBoxColumn
            // 
            this.sexDataGridViewTextBoxColumn.DataPropertyName = "Sex";
            this.sexDataGridViewTextBoxColumn.HeaderText = "Sex";
            this.sexDataGridViewTextBoxColumn.Name = "sexDataGridViewTextBoxColumn";
            // 
            // dateofBirthDataGridViewTextBoxColumn
            // 
            this.dateofBirthDataGridViewTextBoxColumn.DataPropertyName = "Date_of_Birth";
            this.dateofBirthDataGridViewTextBoxColumn.HeaderText = "Date_of_Birth";
            this.dateofBirthDataGridViewTextBoxColumn.Name = "dateofBirthDataGridViewTextBoxColumn";
            // 
            // departmentDataGridViewTextBoxColumn
            // 
            this.departmentDataGridViewTextBoxColumn.DataPropertyName = "Department";
            this.departmentDataGridViewTextBoxColumn.HeaderText = "Department";
            this.departmentDataGridViewTextBoxColumn.Name = "departmentDataGridViewTextBoxColumn";
            // 
            // doctorsnameDataGridViewTextBoxColumn
            // 
            this.doctorsnameDataGridViewTextBoxColumn.DataPropertyName = "Doctors_name";
            this.doctorsnameDataGridViewTextBoxColumn.HeaderText = "Doctors_name";
            this.doctorsnameDataGridViewTextBoxColumn.Name = "doctorsnameDataGridViewTextBoxColumn";
            // 
            // appointmentdateDataGridViewTextBoxColumn
            // 
            this.appointmentdateDataGridViewTextBoxColumn.DataPropertyName = "Appointment_date";
            this.appointmentdateDataGridViewTextBoxColumn.HeaderText = "Appointment_date";
            this.appointmentdateDataGridViewTextBoxColumn.Name = "appointmentdateDataGridViewTextBoxColumn";
            // 
            // appointmenttimeDataGridViewTextBoxColumn
            // 
            this.appointmenttimeDataGridViewTextBoxColumn.DataPropertyName = "Appointment_time";
            this.appointmenttimeDataGridViewTextBoxColumn.HeaderText = "Appointment_time";
            this.appointmenttimeDataGridViewTextBoxColumn.Name = "appointmenttimeDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address_";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address_";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // appointmenttableBindingSource
            // 
            this.appointmenttableBindingSource.DataMember = "Appointment_table";
            this.appointmenttableBindingSource.DataSource = this.hospitalManagmentSystDataSet7;
            // 
            // hospitalManagmentSystDataSet7
            // 
            this.hospitalManagmentSystDataSet7.DataSetName = "HospitalManagmentSystDataSet7";
            this.hospitalManagmentSystDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // appointment_tableTableAdapter
            // 
            this.appointment_tableTableAdapter.ClearBeforeFill = true;
            // 
            // Appointmentform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(873, 586);
            this.Controls.Add(this.userformcontrolpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Appointmentform";
            this.Text = "Appointmentform";
            this.Load += new System.EventHandler(this.Appointmentform_Load);
            this.userformcontrolpanel.ResumeLayout(false);
            this.userformcontrolpanel.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.centralappointcontrol.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchappointmentbtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointmenttableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hospitalManagmentSystDataSet7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuDropdown doctorsnameapptext;
        private Bunifu.Framework.UI.BunifuDatepicker pointmentdatepicker;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.Framework.UI.BunifuMaterialTextbox firsnametextbox;
        private Bunifu.Framework.UI.BunifuMaterialTextbox emailtextbox;
        private Bunifu.Framework.UI.BunifuMaterialTextbox phonenumbertextbox;
        private Bunifu.Framework.UI.BunifuFlatButton sendappoitment;
        private Bunifu.Framework.UI.BunifuFlatButton cancelappointmentbtn;
        private System.Windows.Forms.Panel userformcontrolpanel;
        private Bunifu.Framework.UI.BunifuMaterialTextbox lastnametextbox;
        private System.Windows.Forms.Label appointime;
        private Bunifu.Framework.UI.BunifuDropdown timedropbox;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuDatepicker patientsbirdatetext;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label addres;
        private System.Windows.Forms.TextBox addresstextbox;
        private Bunifu.Framework.UI.BunifuDropdown sexappoitmentdropbox;
        private System.Windows.Forms.Label label12;
        private Bunifu.Framework.UI.BunifuDatepicker birthofdatepickerappoint;
        private Bunifu.Framework.UI.BunifuFlatButton seetodayappointment;
        private System.Windows.Forms.Panel centralappointcontrol;
        private System.Windows.Forms.GroupBox groupBox3;
        private Bunifu.Framework.UI.BunifuCircleProgressbar progresscircle;
        private Bunifu.Framework.UI.BunifuFlatButton makenewappointment;
        private Bunifu.Framework.UI.BunifuMetroTextbox searchtextboxapp;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuImageButton searchappointmentbtn;
        private Bunifu.Framework.UI.BunifuCustomDataGrid bunifuCustomDataGrid1;
        private System.Windows.Forms.Label label13;
        public Bunifu.Framework.UI.BunifuDropdown departmentdropdownbtn;
        private HospitalManagmentSystDataSet7 hospitalManagmentSystDataSet7;
        private System.Windows.Forms.BindingSource appointmenttableBindingSource;
        private HospitalManagmentSystDataSet7TableAdapters.Appointment_tableTableAdapter appointment_tableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn numberİdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phonenumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sexDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateofBirthDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn departmentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn doctorsnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointmentdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointmenttimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.GroupBox groupBox2;
        private Bunifu.Framework.UI.BunifuCustomLabel numberappoint;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        private System.Windows.Forms.PictureBox pictureBox3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private Bunifu.Framework.UI.BunifuCustomLabel tomorrowappointment;
        private Bunifu.Framework.UI.BunifuCircleProgressbar tomorrowporgresscircle;
    }
}