﻿using System;


namespace HProgramming
{
    class Appointmentİnformation : Employeesİnfomation { 
        public DateTime appointmentdate { get; set; }
        public string doctorname { get; set; }
        public string appoitmenttime { get; set; }
    }
}
