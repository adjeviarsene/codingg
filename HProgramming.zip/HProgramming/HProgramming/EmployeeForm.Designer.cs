﻿namespace HProgramming
{
    partial class EmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.addresstextbox = new System.Windows.Forms.TextBox();
            this.birthdatepicker = new Bunifu.Framework.UI.BunifuDatepicker();
            this.sexempldropbox = new Bunifu.Framework.UI.BunifuDropdown();
            this.civilstatusdropbox = new Bunifu.Framework.UI.BunifuDropdown();
            this.lastnameempltextbox = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.firstnameempltextbox = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.phonenumbertextbox = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.emailempltextbox = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.idempltextbox = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel18 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.paymethodetextbox = new Bunifu.Framework.UI.BunifuDropdown();
            this.hirededatepicker = new Bunifu.Framework.UI.BunifuDatepicker();
            this.workstatusdropbox = new Bunifu.Framework.UI.BunifuDropdown();
            this.positionbtext = new Bunifu.Framework.UI.BunifuDropdown();
            this.departmentdropbox = new Bunifu.Framework.UI.BunifuDropdown();
            this.dailyratetextbox = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel12 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel16 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel15 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel17 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel14 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel13 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.viewempllistbtn = new Bunifu.Framework.UI.BunifuFlatButton();
            this.updatebtn = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Dalete = new Bunifu.Framework.UI.BunifuFlatButton();
            this.sendtodatabasebtn = new Bunifu.Framework.UI.BunifuFlatButton();
            this.centralcotrolledpanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomLabel20 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel19 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.addnewemplbtn = new Bunifu.Framework.UI.BunifuFlatButton();
            this.searchbtn = new Bunifu.Framework.UI.BunifuImageButton();
            this.searchtextbox = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomDataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeetableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.hospitalManagmentSystDataSet5 = new HProgramming.HospitalManagmentSystDataSet5();
            this.employee_tableTableAdapter = new HProgramming.HospitalManagmentSystDataSet5TableAdapters.Employee_tableTableAdapter();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.centralcotrolledpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchbtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeetableBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hospitalManagmentSystDataSet5)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.addresstextbox);
            this.groupBox1.Controls.Add(this.birthdatepicker);
            this.groupBox1.Controls.Add(this.sexempldropbox);
            this.groupBox1.Controls.Add(this.civilstatusdropbox);
            this.groupBox1.Controls.Add(this.lastnameempltextbox);
            this.groupBox1.Controls.Add(this.firstnameempltextbox);
            this.groupBox1.Controls.Add(this.phonenumbertextbox);
            this.groupBox1.Controls.Add(this.emailempltextbox);
            this.groupBox1.Controls.Add(this.idempltextbox);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel18);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel11);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel9);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel8);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel7);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel6);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel5);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel4);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel3);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox1.Location = new System.Drawing.Point(3, 71);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(858, 249);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personel İnformations";
            // 
            // addresstextbox
            // 
            this.addresstextbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.addresstextbox.ForeColor = System.Drawing.Color.White;
            this.addresstextbox.Location = new System.Drawing.Point(665, 162);
            this.addresstextbox.Multiline = true;
            this.addresstextbox.Name = "addresstextbox";
            this.addresstextbox.Size = new System.Drawing.Size(184, 68);
            this.addresstextbox.TabIndex = 5;
            this.addresstextbox.Text = "Current Address";
            this.addresstextbox.TextChanged += new System.EventHandler(this.addresstextbox_TextChanged);
            this.addresstextbox.Enter += new System.EventHandler(this.addresstextbox_Enter);
            this.addresstextbox.Leave += new System.EventHandler(this.addresstextbox_Leave);
            // 
            // birthdatepicker
            // 
            this.birthdatepicker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.birthdatepicker.BorderRadius = 0;
            this.birthdatepicker.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.birthdatepicker.ForeColor = System.Drawing.Color.White;
            this.birthdatepicker.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.birthdatepicker.FormatCustom = null;
            this.birthdatepicker.Location = new System.Drawing.Point(337, 99);
            this.birthdatepicker.Name = "birthdatepicker";
            this.birthdatepicker.Size = new System.Drawing.Size(199, 36);
            this.birthdatepicker.TabIndex = 4;
            this.birthdatepicker.Value = new System.DateTime(2020, 5, 11, 0, 34, 22, 542);
            this.birthdatepicker.onValueChanged += new System.EventHandler(this.birthdatepicker_onValueChanged);
            // 
            // sexempldropbox
            // 
            this.sexempldropbox.BackColor = System.Drawing.Color.Transparent;
            this.sexempldropbox.BorderRadius = 3;
            this.sexempldropbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.sexempldropbox.ForeColor = System.Drawing.Color.White;
            this.sexempldropbox.Items = new string[] {
        "Male",
        "Female",
        "Others"};
            this.sexempldropbox.Location = new System.Drawing.Point(337, 162);
            this.sexempldropbox.Name = "sexempldropbox";
            this.sexempldropbox.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.sexempldropbox.onHoverColor = System.Drawing.Color.Teal;
            this.sexempldropbox.selectedIndex = -1;
            this.sexempldropbox.Size = new System.Drawing.Size(170, 40);
            this.sexempldropbox.TabIndex = 3;
            this.sexempldropbox.onItemSelected += new System.EventHandler(this.ssexempldropbox_onItemSelected);
            // 
            // civilstatusdropbox
            // 
            this.civilstatusdropbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.civilstatusdropbox.BorderRadius = 3;
            this.civilstatusdropbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.civilstatusdropbox.ForeColor = System.Drawing.Color.White;
            this.civilstatusdropbox.Items = new string[] {
        "Single",
        "Married",
        "Divorced",
        "Widowed",
        "Engaged"};
            this.civilstatusdropbox.Location = new System.Drawing.Point(703, 99);
            this.civilstatusdropbox.Name = "civilstatusdropbox";
            this.civilstatusdropbox.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.civilstatusdropbox.onHoverColor = System.Drawing.Color.Teal;
            this.civilstatusdropbox.selectedIndex = -1;
            this.civilstatusdropbox.Size = new System.Drawing.Size(146, 35);
            this.civilstatusdropbox.TabIndex = 3;
            this.civilstatusdropbox.onItemSelected += new System.EventHandler(this.civilstatusdropbox_onItemSelected);
            // 
            // lastnameempltextbox
            // 
            this.lastnameempltextbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lastnameempltextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.lastnameempltextbox.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.lastnameempltextbox.ForeColor = System.Drawing.Color.White;
            this.lastnameempltextbox.HintForeColor = System.Drawing.Color.Empty;
            this.lastnameempltextbox.HintText = "";
            this.lastnameempltextbox.isPassword = false;
            this.lastnameempltextbox.LineFocusedColor = System.Drawing.Color.SlateGray;
            this.lastnameempltextbox.LineIdleColor = System.Drawing.Color.Gray;
            this.lastnameempltextbox.LineMouseHoverColor = System.Drawing.Color.Teal;
            this.lastnameempltextbox.LineThickness = 3;
            this.lastnameempltextbox.Location = new System.Drawing.Point(90, 186);
            this.lastnameempltextbox.Margin = new System.Windows.Forms.Padding(4);
            this.lastnameempltextbox.Name = "lastnameempltextbox";
            this.lastnameempltextbox.Size = new System.Drawing.Size(123, 44);
            this.lastnameempltextbox.TabIndex = 2;
            this.lastnameempltextbox.Text = "lastname";
            this.lastnameempltextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.lastnameempltextbox.OnValueChanged += new System.EventHandler(this.lsatnameempltextbox_OnValueChanged);
            this.lastnameempltextbox.Enter += new System.EventHandler(this.lastnameempltextbox_Enter);
            this.lastnameempltextbox.Leave += new System.EventHandler(this.lastnameempltextbox_Leave);
            // 
            // firstnameempltextbox
            // 
            this.firstnameempltextbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.firstnameempltextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.firstnameempltextbox.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.firstnameempltextbox.ForeColor = System.Drawing.Color.White;
            this.firstnameempltextbox.HintForeColor = System.Drawing.Color.Empty;
            this.firstnameempltextbox.HintText = "";
            this.firstnameempltextbox.isPassword = false;
            this.firstnameempltextbox.LineFocusedColor = System.Drawing.Color.SlateGray;
            this.firstnameempltextbox.LineIdleColor = System.Drawing.Color.Gray;
            this.firstnameempltextbox.LineMouseHoverColor = System.Drawing.Color.Teal;
            this.firstnameempltextbox.LineThickness = 3;
            this.firstnameempltextbox.Location = new System.Drawing.Point(90, 122);
            this.firstnameempltextbox.Margin = new System.Windows.Forms.Padding(4);
            this.firstnameempltextbox.Name = "firstnameempltextbox";
            this.firstnameempltextbox.Size = new System.Drawing.Size(123, 44);
            this.firstnameempltextbox.TabIndex = 2;
            this.firstnameempltextbox.Text = "firstname";
            this.firstnameempltextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.firstnameempltextbox.OnValueChanged += new System.EventHandler(this.firstnameempltextbox_OnValueChanged);
            this.firstnameempltextbox.Enter += new System.EventHandler(this.firstnameempltextbox_Enter);
            this.firstnameempltextbox.Leave += new System.EventHandler(this.firstnameempltextbox_Leave);
            // 
            // phonenumbertextbox
            // 
            this.phonenumbertextbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.phonenumbertextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.phonenumbertextbox.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.phonenumbertextbox.ForeColor = System.Drawing.Color.White;
            this.phonenumbertextbox.HintForeColor = System.Drawing.Color.Empty;
            this.phonenumbertextbox.HintText = "";
            this.phonenumbertextbox.isPassword = false;
            this.phonenumbertextbox.LineFocusedColor = System.Drawing.Color.SlateGray;
            this.phonenumbertextbox.LineIdleColor = System.Drawing.Color.Gray;
            this.phonenumbertextbox.LineMouseHoverColor = System.Drawing.Color.Teal;
            this.phonenumbertextbox.LineThickness = 3;
            this.phonenumbertextbox.Location = new System.Drawing.Point(726, 39);
            this.phonenumbertextbox.Margin = new System.Windows.Forms.Padding(4);
            this.phonenumbertextbox.Name = "phonenumbertextbox";
            this.phonenumbertextbox.Size = new System.Drawing.Size(123, 44);
            this.phonenumbertextbox.TabIndex = 2;
            this.phonenumbertextbox.Text = "Phone number";
            this.phonenumbertextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.phonenumbertextbox.OnValueChanged += new System.EventHandler(this.phonenumbertextbox_OnValueChanged);
            // 
            // emailempltextbox
            // 
            this.emailempltextbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.emailempltextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.emailempltextbox.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.emailempltextbox.ForeColor = System.Drawing.Color.White;
            this.emailempltextbox.HintForeColor = System.Drawing.Color.Empty;
            this.emailempltextbox.HintText = "";
            this.emailempltextbox.isPassword = false;
            this.emailempltextbox.LineFocusedColor = System.Drawing.Color.SlateGray;
            this.emailempltextbox.LineIdleColor = System.Drawing.Color.Gray;
            this.emailempltextbox.LineMouseHoverColor = System.Drawing.Color.Teal;
            this.emailempltextbox.LineThickness = 3;
            this.emailempltextbox.Location = new System.Drawing.Point(337, 39);
            this.emailempltextbox.Margin = new System.Windows.Forms.Padding(4);
            this.emailempltextbox.Name = "emailempltextbox";
            this.emailempltextbox.Size = new System.Drawing.Size(123, 44);
            this.emailempltextbox.TabIndex = 2;
            this.emailempltextbox.Text = "Valid Email";
            this.emailempltextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.emailempltextbox.OnValueChanged += new System.EventHandler(this.emailempltextbox_OnValueChanged);
            this.emailempltextbox.Enter += new System.EventHandler(this.emailempltextbox_Enter);
            this.emailempltextbox.Leave += new System.EventHandler(this.emailempltextbox_Leave);
            // 
            // idempltextbox
            // 
            this.idempltextbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.idempltextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.idempltextbox.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.idempltextbox.ForeColor = System.Drawing.Color.White;
            this.idempltextbox.HintForeColor = System.Drawing.Color.Empty;
            this.idempltextbox.HintText = "";
            this.idempltextbox.isPassword = false;
            this.idempltextbox.LineFocusedColor = System.Drawing.Color.SlateGray;
            this.idempltextbox.LineIdleColor = System.Drawing.Color.Gray;
            this.idempltextbox.LineMouseHoverColor = System.Drawing.Color.Teal;
            this.idempltextbox.LineThickness = 3;
            this.idempltextbox.Location = new System.Drawing.Point(90, 39);
            this.idempltextbox.Margin = new System.Windows.Forms.Padding(4);
            this.idempltextbox.Name = "idempltextbox";
            this.idempltextbox.Size = new System.Drawing.Size(123, 44);
            this.idempltextbox.TabIndex = 2;
            this.idempltextbox.Text = "Enter_Valid_İD";
            this.idempltextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.idempltextbox.OnValueChanged += new System.EventHandler(this.idempltextbox_OnValueChanged);
            this.idempltextbox.Enter += new System.EventHandler(this.idempltextbox_Enter);
            this.idempltextbox.Leave += new System.EventHandler(this.idempltextbox_Leave);
            // 
            // bunifuCustomLabel18
            // 
            this.bunifuCustomLabel18.AutoSize = true;
            this.bunifuCustomLabel18.Location = new System.Drawing.Point(567, 109);
            this.bunifuCustomLabel18.Name = "bunifuCustomLabel18";
            this.bunifuCustomLabel18.Size = new System.Drawing.Size(78, 15);
            this.bunifuCustomLabel18.TabIndex = 1;
            this.bunifuCustomLabel18.Text = "Civil_satatus:";
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(567, 56);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(96, 15);
            this.bunifuCustomLabel11.TabIndex = 1;
            this.bunifuCustomLabel11.Text = "Phone_nomber:";
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(567, 200);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(54, 15);
            this.bunifuCustomLabel9.TabIndex = 1;
            this.bunifuCustomLabel9.Text = "Address:";
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(536, 39);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(0, 15);
            this.bunifuCustomLabel8.TabIndex = 1;
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(247, 56);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(42, 15);
            this.bunifuCustomLabel7.TabIndex = 1;
            this.bunifuCustomLabel7.Text = "Email:";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(247, 109);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(68, 15);
            this.bunifuCustomLabel6.TabIndex = 1;
            this.bunifuCustomLabel6.Text = "Birth_Date:";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(247, 186);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(31, 15);
            this.bunifuCustomLabel5.TabIndex = 1;
            this.bunifuCustomLabel5.Text = "Sex:";
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(6, 200);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(65, 15);
            this.bunifuCustomLabel4.TabIndex = 1;
            this.bunifuCustomLabel4.Text = "Lastname:";
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(6, 138);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(65, 15);
            this.bunifuCustomLabel3.TabIndex = 1;
            this.bunifuCustomLabel3.Text = "Firstname:";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(6, 56);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(77, 15);
            this.bunifuCustomLabel2.TabIndex = 1;
            this.bunifuCustomLabel2.Text = "EmployeeİD:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.paymethodetextbox);
            this.groupBox2.Controls.Add(this.hirededatepicker);
            this.groupBox2.Controls.Add(this.workstatusdropbox);
            this.groupBox2.Controls.Add(this.positionbtext);
            this.groupBox2.Controls.Add(this.departmentdropbox);
            this.groupBox2.Controls.Add(this.dailyratetextbox);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel12);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel16);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel15);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel17);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel14);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel13);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel10);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox2.Location = new System.Drawing.Point(3, 326);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(858, 171);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Work İnformations";
            // 
            // paymethodetextbox
            // 
            this.paymethodetextbox.BackColor = System.Drawing.Color.Transparent;
            this.paymethodetextbox.BorderRadius = 3;
            this.paymethodetextbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.paymethodetextbox.ForeColor = System.Drawing.Color.White;
            this.paymethodetextbox.Items = new string[] {
        "Daily",
        "Weekly",
        "Monthly",
        "Orthers"};
            this.paymethodetextbox.Location = new System.Drawing.Point(104, 102);
            this.paymethodetextbox.Name = "paymethodetextbox";
            this.paymethodetextbox.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.paymethodetextbox.onHoverColor = System.Drawing.Color.Teal;
            this.paymethodetextbox.selectedIndex = -1;
            this.paymethodetextbox.Size = new System.Drawing.Size(150, 26);
            this.paymethodetextbox.TabIndex = 3;
            this.paymethodetextbox.onItemSelected += new System.EventHandler(this.paymethodetextbox_onItemSelected);
            // 
            // hirededatepicker
            // 
            this.hirededatepicker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.hirededatepicker.BorderRadius = 0;
            this.hirededatepicker.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.hirededatepicker.ForeColor = System.Drawing.Color.White;
            this.hirededatepicker.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.hirededatepicker.FormatCustom = null;
            this.hirededatepicker.Location = new System.Drawing.Point(665, 21);
            this.hirededatepicker.Name = "hirededatepicker";
            this.hirededatepicker.Size = new System.Drawing.Size(188, 41);
            this.hirededatepicker.TabIndex = 4;
            this.hirededatepicker.Value = new System.DateTime(2020, 5, 11, 0, 34, 22, 542);
            this.hirededatepicker.onValueChanged += new System.EventHandler(this.hirededatepicker_onValueChanged);
            // 
            // workstatusdropbox
            // 
            this.workstatusdropbox.BackColor = System.Drawing.Color.Transparent;
            this.workstatusdropbox.BorderRadius = 3;
            this.workstatusdropbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.workstatusdropbox.ForeColor = System.Drawing.Color.White;
            this.workstatusdropbox.Items = new string[] {
        "Part_time",
        "Full_time",
        "Stage",
        "Scientist_Recherche",
        "Others"};
            this.workstatusdropbox.Location = new System.Drawing.Point(670, 95);
            this.workstatusdropbox.Name = "workstatusdropbox";
            this.workstatusdropbox.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.workstatusdropbox.onHoverColor = System.Drawing.Color.Teal;
            this.workstatusdropbox.selectedIndex = -1;
            this.workstatusdropbox.Size = new System.Drawing.Size(175, 33);
            this.workstatusdropbox.TabIndex = 3;
            this.workstatusdropbox.onItemSelected += new System.EventHandler(this.workstatusdropbox_onItemSelected);
            // 
            // positionbtext
            // 
            this.positionbtext.BackColor = System.Drawing.Color.Transparent;
            this.positionbtext.BorderRadius = 3;
            this.positionbtext.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.positionbtext.ForeColor = System.Drawing.Color.White;
            this.positionbtext.Items = new string[] {
        "Healthcare Administrator",
        "Medical Administrative",
        "Business Analysts",
        "Chief Recruitment Manager",
        "Admissions Director",
        "Senior Surgeons",
        "Specialized Doctors",
        "Silent Doctors",
        "Junior Doctors",
        "Practitioners",
        "Head Nurse",
        "Registered Nurses",
        "Nurse",
        "Nurse Practitioner",
        "Medical Secretary",
        "Medical Technologist",
        "Medical Technician",
        "Occupational Therapist",
        "Nutritionist",
        "Medical Assistant",
        "Nursing Home Administrator",
        "Senior Physician",
        "Physician",
        "Physician’s Assistant",
        "Financial Analyst",
        "Medical Transcriptionist",
        "Front Office Help",
        "Clerical Staff",
        "Medical Biller",
        "Pharmacist",
        "Patient Services Technician",
        "Patient Care Associate",
        "Phlebotomist",
        "Health Educator",
        "Pharmaceutical Sales Representative",
        "Receptionist",
        "Cleaners",
        "Helpers"};
            this.positionbtext.Location = new System.Drawing.Point(395, 33);
            this.positionbtext.Name = "positionbtext";
            this.positionbtext.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.positionbtext.onHoverColor = System.Drawing.Color.Teal;
            this.positionbtext.selectedIndex = -1;
            this.positionbtext.Size = new System.Drawing.Size(171, 29);
            this.positionbtext.TabIndex = 3;
            this.positionbtext.onItemSelected += new System.EventHandler(this.positionbtext_onItemSelected);
            // 
            // departmentdropbox
            // 
            this.departmentdropbox.BackColor = System.Drawing.Color.Transparent;
            this.departmentdropbox.BorderRadius = 3;
            this.departmentdropbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.departmentdropbox.ForeColor = System.Drawing.Color.White;
            this.departmentdropbox.Items = new string[] {
        "Neurology",
        "Toxicology",
        "Chirurgy",
        "Hematology",
        "İnfections Deseases",
        "Oncology"};
            this.departmentdropbox.Location = new System.Drawing.Point(395, 95);
            this.departmentdropbox.Name = "departmentdropbox";
            this.departmentdropbox.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.departmentdropbox.onHoverColor = System.Drawing.Color.Teal;
            this.departmentdropbox.selectedIndex = -1;
            this.departmentdropbox.Size = new System.Drawing.Size(184, 33);
            this.departmentdropbox.TabIndex = 3;
            this.departmentdropbox.onItemSelected += new System.EventHandler(this.departmentdropbox_onItemSelected);
            // 
            // dailyratetextbox
            // 
            this.dailyratetextbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dailyratetextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.dailyratetextbox.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.dailyratetextbox.ForeColor = System.Drawing.Color.White;
            this.dailyratetextbox.HintForeColor = System.Drawing.Color.Empty;
            this.dailyratetextbox.HintText = "";
            this.dailyratetextbox.isPassword = false;
            this.dailyratetextbox.LineFocusedColor = System.Drawing.Color.SlateGray;
            this.dailyratetextbox.LineIdleColor = System.Drawing.Color.Gray;
            this.dailyratetextbox.LineMouseHoverColor = System.Drawing.Color.Teal;
            this.dailyratetextbox.LineThickness = 3;
            this.dailyratetextbox.Location = new System.Drawing.Point(104, 47);
            this.dailyratetextbox.Margin = new System.Windows.Forms.Padding(4);
            this.dailyratetextbox.Name = "dailyratetextbox";
            this.dailyratetextbox.Size = new System.Drawing.Size(123, 31);
            this.dailyratetextbox.TabIndex = 2;
            this.dailyratetextbox.Text = "Rate";
            this.dailyratetextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.dailyratetextbox.OnValueChanged += new System.EventHandler(this.dailyratetextbox_OnValueChanged);
            this.dailyratetextbox.Enter += new System.EventHandler(this.dailyratetextbox_Enter);
            this.dailyratetextbox.Leave += new System.EventHandler(this.dailyratetextbox_Leave);
            // 
            // bunifuCustomLabel12
            // 
            this.bunifuCustomLabel12.AutoSize = true;
            this.bunifuCustomLabel12.Location = new System.Drawing.Point(536, -145);
            this.bunifuCustomLabel12.Name = "bunifuCustomLabel12";
            this.bunifuCustomLabel12.Size = new System.Drawing.Size(121, 15);
            this.bunifuCustomLabel12.TabIndex = 1;
            this.bunifuCustomLabel12.Text = "bunifuCustomLabel1";
            // 
            // bunifuCustomLabel16
            // 
            this.bunifuCustomLabel16.AutoSize = true;
            this.bunifuCustomLabel16.Location = new System.Drawing.Point(572, 34);
            this.bunifuCustomLabel16.Name = "bunifuCustomLabel16";
            this.bunifuCustomLabel16.Size = new System.Drawing.Size(73, 15);
            this.bunifuCustomLabel16.TabIndex = 1;
            this.bunifuCustomLabel16.Text = "Date_Hired:";
            // 
            // bunifuCustomLabel15
            // 
            this.bunifuCustomLabel15.AutoSize = true;
            this.bunifuCustomLabel15.Location = new System.Drawing.Point(311, 34);
            this.bunifuCustomLabel15.Name = "bunifuCustomLabel15";
            this.bunifuCustomLabel15.Size = new System.Drawing.Size(54, 15);
            this.bunifuCustomLabel15.TabIndex = 1;
            this.bunifuCustomLabel15.Text = "Position:";
            // 
            // bunifuCustomLabel17
            // 
            this.bunifuCustomLabel17.AutoSize = true;
            this.bunifuCustomLabel17.Location = new System.Drawing.Point(585, 102);
            this.bunifuCustomLabel17.Name = "bunifuCustomLabel17";
            this.bunifuCustomLabel17.Size = new System.Drawing.Size(79, 15);
            this.bunifuCustomLabel17.TabIndex = 1;
            this.bunifuCustomLabel17.Text = "Work_Status:";
            // 
            // bunifuCustomLabel14
            // 
            this.bunifuCustomLabel14.AutoSize = true;
            this.bunifuCustomLabel14.Location = new System.Drawing.Point(311, 102);
            this.bunifuCustomLabel14.Name = "bunifuCustomLabel14";
            this.bunifuCustomLabel14.Size = new System.Drawing.Size(75, 15);
            this.bunifuCustomLabel14.TabIndex = 1;
            this.bunifuCustomLabel14.Text = "Department:";
            // 
            // bunifuCustomLabel13
            // 
            this.bunifuCustomLabel13.AutoSize = true;
            this.bunifuCustomLabel13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel13.Location = new System.Drawing.Point(6, 47);
            this.bunifuCustomLabel13.Name = "bunifuCustomLabel13";
            this.bunifuCustomLabel13.Size = new System.Drawing.Size(70, 15);
            this.bunifuCustomLabel13.TabIndex = 1;
            this.bunifuCustomLabel13.Text = "Daily_Rate:";
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(6, 102);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(86, 15);
            this.bunifuCustomLabel10.TabIndex = 1;
            this.bunifuCustomLabel10.Text = "Pay_Methode:";
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("RomanT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(121, 38);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(544, 39);
            this.bunifuCustomLabel1.TabIndex = 1;
            this.bunifuCustomLabel1.Text = "Employees Registration Forms";
            // 
            // viewempllistbtn
            // 
            this.viewempllistbtn.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.viewempllistbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.viewempllistbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.viewempllistbtn.BorderRadius = 0;
            this.viewempllistbtn.ButtonText = "View Employees List";
            this.viewempllistbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.viewempllistbtn.DisabledColor = System.Drawing.Color.Gray;
            this.viewempllistbtn.Iconcolor = System.Drawing.Color.Transparent;
            this.viewempllistbtn.Iconimage = ((System.Drawing.Image)(resources.GetObject("viewempllistbtn.Iconimage")));
            this.viewempllistbtn.Iconimage_right = null;
            this.viewempllistbtn.Iconimage_right_Selected = null;
            this.viewempllistbtn.Iconimage_Selected = null;
            this.viewempllistbtn.IconMarginLeft = 0;
            this.viewempllistbtn.IconMarginRight = 0;
            this.viewempllistbtn.IconRightVisible = true;
            this.viewempllistbtn.IconRightZoom = 0D;
            this.viewempllistbtn.IconVisible = true;
            this.viewempllistbtn.IconZoom = 90D;
            this.viewempllistbtn.IsTab = false;
            this.viewempllistbtn.Location = new System.Drawing.Point(671, 29);
            this.viewempllistbtn.Name = "viewempllistbtn";
            this.viewempllistbtn.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.viewempllistbtn.OnHovercolor = System.Drawing.Color.Teal;
            this.viewempllistbtn.OnHoverTextColor = System.Drawing.Color.White;
            this.viewempllistbtn.selected = false;
            this.viewempllistbtn.Size = new System.Drawing.Size(184, 48);
            this.viewempllistbtn.TabIndex = 2;
            this.viewempllistbtn.Text = "View Employees List";
            this.viewempllistbtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.viewempllistbtn.Textcolor = System.Drawing.Color.White;
            this.viewempllistbtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewempllistbtn.Click += new System.EventHandler(this.viewempllistbtn_Click);
            // 
            // updatebtn
            // 
            this.updatebtn.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.updatebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.updatebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.updatebtn.BorderRadius = 0;
            this.updatebtn.ButtonText = "Update";
            this.updatebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.updatebtn.DisabledColor = System.Drawing.Color.Gray;
            this.updatebtn.Iconcolor = System.Drawing.Color.Transparent;
            this.updatebtn.Iconimage = ((System.Drawing.Image)(resources.GetObject("updatebtn.Iconimage")));
            this.updatebtn.Iconimage_right = null;
            this.updatebtn.Iconimage_right_Selected = null;
            this.updatebtn.Iconimage_Selected = null;
            this.updatebtn.IconMarginLeft = 0;
            this.updatebtn.IconMarginRight = 0;
            this.updatebtn.IconRightVisible = true;
            this.updatebtn.IconRightZoom = 0D;
            this.updatebtn.IconVisible = true;
            this.updatebtn.IconZoom = 90D;
            this.updatebtn.IsTab = false;
            this.updatebtn.Location = new System.Drawing.Point(591, 526);
            this.updatebtn.Name = "updatebtn";
            this.updatebtn.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.updatebtn.OnHovercolor = System.Drawing.Color.Teal;
            this.updatebtn.OnHoverTextColor = System.Drawing.Color.White;
            this.updatebtn.selected = false;
            this.updatebtn.Size = new System.Drawing.Size(118, 48);
            this.updatebtn.TabIndex = 2;
            this.updatebtn.Text = "Update";
            this.updatebtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.updatebtn.Textcolor = System.Drawing.Color.White;
            this.updatebtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatebtn.Click += new System.EventHandler(this.updatebtn_Click);
            // 
            // Dalete
            // 
            this.Dalete.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.Dalete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.Dalete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Dalete.BorderRadius = 0;
            this.Dalete.ButtonText = "Delete";
            this.Dalete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Dalete.DisabledColor = System.Drawing.Color.Gray;
            this.Dalete.Iconcolor = System.Drawing.Color.Transparent;
            this.Dalete.Iconimage = ((System.Drawing.Image)(resources.GetObject("Dalete.Iconimage")));
            this.Dalete.Iconimage_right = null;
            this.Dalete.Iconimage_right_Selected = null;
            this.Dalete.Iconimage_Selected = null;
            this.Dalete.IconMarginLeft = 0;
            this.Dalete.IconMarginRight = 0;
            this.Dalete.IconRightVisible = true;
            this.Dalete.IconRightZoom = 0D;
            this.Dalete.IconVisible = true;
            this.Dalete.IconZoom = 90D;
            this.Dalete.IsTab = false;
            this.Dalete.Location = new System.Drawing.Point(738, 526);
            this.Dalete.Name = "Dalete";
            this.Dalete.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.Dalete.OnHovercolor = System.Drawing.Color.Teal;
            this.Dalete.OnHoverTextColor = System.Drawing.Color.White;
            this.Dalete.selected = false;
            this.Dalete.Size = new System.Drawing.Size(114, 48);
            this.Dalete.TabIndex = 2;
            this.Dalete.Text = "Delete";
            this.Dalete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Dalete.Textcolor = System.Drawing.Color.White;
            this.Dalete.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dalete.Click += new System.EventHandler(this.Dalete_Click);
            // 
            // sendtodatabasebtn
            // 
            this.sendtodatabasebtn.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.sendtodatabasebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.sendtodatabasebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sendtodatabasebtn.BorderRadius = 0;
            this.sendtodatabasebtn.ButtonText = "Send ToDatabase";
            this.sendtodatabasebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sendtodatabasebtn.DisabledColor = System.Drawing.Color.Gray;
            this.sendtodatabasebtn.Iconcolor = System.Drawing.Color.Transparent;
            this.sendtodatabasebtn.Iconimage = ((System.Drawing.Image)(resources.GetObject("sendtodatabasebtn.Iconimage")));
            this.sendtodatabasebtn.Iconimage_right = null;
            this.sendtodatabasebtn.Iconimage_right_Selected = null;
            this.sendtodatabasebtn.Iconimage_Selected = null;
            this.sendtodatabasebtn.IconMarginLeft = 0;
            this.sendtodatabasebtn.IconMarginRight = 0;
            this.sendtodatabasebtn.IconRightVisible = true;
            this.sendtodatabasebtn.IconRightZoom = 0D;
            this.sendtodatabasebtn.IconVisible = true;
            this.sendtodatabasebtn.IconZoom = 90D;
            this.sendtodatabasebtn.IsTab = false;
            this.sendtodatabasebtn.Location = new System.Drawing.Point(391, 526);
            this.sendtodatabasebtn.Name = "sendtodatabasebtn";
            this.sendtodatabasebtn.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.sendtodatabasebtn.OnHovercolor = System.Drawing.Color.Teal;
            this.sendtodatabasebtn.OnHoverTextColor = System.Drawing.Color.White;
            this.sendtodatabasebtn.selected = false;
            this.sendtodatabasebtn.Size = new System.Drawing.Size(175, 48);
            this.sendtodatabasebtn.TabIndex = 2;
            this.sendtodatabasebtn.Text = "Send ToDatabase";
            this.sendtodatabasebtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sendtodatabasebtn.Textcolor = System.Drawing.Color.White;
            this.sendtodatabasebtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sendtodatabasebtn.Click += new System.EventHandler(this.sendtodatabasebtn_Click);
            // 
            // centralcotrolledpanel
            // 
            this.centralcotrolledpanel.Controls.Add(this.pictureBox1);
            this.centralcotrolledpanel.Controls.Add(this.bunifuCustomLabel20);
            this.centralcotrolledpanel.Controls.Add(this.bunifuCustomLabel19);
            this.centralcotrolledpanel.Controls.Add(this.addnewemplbtn);
            this.centralcotrolledpanel.Controls.Add(this.searchbtn);
            this.centralcotrolledpanel.Controls.Add(this.searchtextbox);
            this.centralcotrolledpanel.Controls.Add(this.bunifuCustomDataGrid1);
            this.centralcotrolledpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.centralcotrolledpanel.Location = new System.Drawing.Point(0, 0);
            this.centralcotrolledpanel.Name = "centralcotrolledpanel";
            this.centralcotrolledpanel.Size = new System.Drawing.Size(873, 586);
            this.centralcotrolledpanel.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 477);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 48);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuCustomLabel20
            // 
            this.bunifuCustomLabel20.AutoSize = true;
            this.bunifuCustomLabel20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel20.Location = new System.Drawing.Point(67, 491);
            this.bunifuCustomLabel20.Name = "bunifuCustomLabel20";
            this.bunifuCustomLabel20.Size = new System.Drawing.Size(194, 18);
            this.bunifuCustomLabel20.TabIndex = 4;
            this.bunifuCustomLabel20.Text = "Search Only By EmployeeİD";
            // 
            // bunifuCustomLabel19
            // 
            this.bunifuCustomLabel19.AutoSize = true;
            this.bunifuCustomLabel19.Font = new System.Drawing.Font("RomanT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel19.Location = new System.Drawing.Point(192, 39);
            this.bunifuCustomLabel19.Name = "bunifuCustomLabel19";
            this.bunifuCustomLabel19.Size = new System.Drawing.Size(268, 39);
            this.bunifuCustomLabel19.TabIndex = 4;
            this.bunifuCustomLabel19.Text = "Employees List";
            // 
            // addnewemplbtn
            // 
            this.addnewemplbtn.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.addnewemplbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.addnewemplbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.addnewemplbtn.BorderRadius = 0;
            this.addnewemplbtn.ButtonText = "Add New Employee";
            this.addnewemplbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addnewemplbtn.DisabledColor = System.Drawing.Color.Gray;
            this.addnewemplbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.addnewemplbtn.Iconcolor = System.Drawing.Color.Transparent;
            this.addnewemplbtn.Iconimage = ((System.Drawing.Image)(resources.GetObject("addnewemplbtn.Iconimage")));
            this.addnewemplbtn.Iconimage_right = null;
            this.addnewemplbtn.Iconimage_right_Selected = null;
            this.addnewemplbtn.Iconimage_Selected = null;
            this.addnewemplbtn.IconMarginLeft = 0;
            this.addnewemplbtn.IconMarginRight = 0;
            this.addnewemplbtn.IconRightVisible = true;
            this.addnewemplbtn.IconRightZoom = 0D;
            this.addnewemplbtn.IconVisible = true;
            this.addnewemplbtn.IconZoom = 90D;
            this.addnewemplbtn.IsTab = false;
            this.addnewemplbtn.Location = new System.Drawing.Point(686, 491);
            this.addnewemplbtn.Name = "addnewemplbtn";
            this.addnewemplbtn.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.addnewemplbtn.OnHovercolor = System.Drawing.Color.Teal;
            this.addnewemplbtn.OnHoverTextColor = System.Drawing.Color.White;
            this.addnewemplbtn.selected = false;
            this.addnewemplbtn.Size = new System.Drawing.Size(182, 48);
            this.addnewemplbtn.TabIndex = 3;
            this.addnewemplbtn.Text = "Add New Employee";
            this.addnewemplbtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addnewemplbtn.Textcolor = System.Drawing.Color.White;
            this.addnewemplbtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addnewemplbtn.Click += new System.EventHandler(this.addnewemplbtn_Click);
            // 
            // searchbtn
            // 
            this.searchbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.searchbtn.Image = ((System.Drawing.Image)(resources.GetObject("searchbtn.Image")));
            this.searchbtn.ImageActive = null;
            this.searchbtn.Location = new System.Drawing.Point(765, 75);
            this.searchbtn.Name = "searchbtn";
            this.searchbtn.Size = new System.Drawing.Size(67, 49);
            this.searchbtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.searchbtn.TabIndex = 2;
            this.searchbtn.TabStop = false;
            this.searchbtn.Zoom = 10;
            this.searchbtn.Click += new System.EventHandler(this.searchbtn_Click);
            // 
            // searchtextbox
            // 
            this.searchtextbox.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.searchtextbox.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.searchtextbox.BorderColorMouseHover = System.Drawing.Color.Teal;
            this.searchtextbox.BorderThickness = 3;
            this.searchtextbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.searchtextbox.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.searchtextbox.ForeColor = System.Drawing.Color.White;
            this.searchtextbox.isPassword = false;
            this.searchtextbox.Location = new System.Drawing.Point(503, 77);
            this.searchtextbox.Margin = new System.Windows.Forms.Padding(4);
            this.searchtextbox.Name = "searchtextbox";
            this.searchtextbox.Size = new System.Drawing.Size(243, 44);
            this.searchtextbox.TabIndex = 1;
            this.searchtextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.searchtextbox.OnValueChanged += new System.EventHandler(this.searchtextbox_OnValueChanged);
            // 
            // bunifuCustomDataGrid1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuCustomDataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.bunifuCustomDataGrid1.AutoGenerateColumns = false;
            this.bunifuCustomDataGrid1.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuCustomDataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Lime;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuCustomDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.bunifuCustomDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bunifuCustomDataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16});
            this.bunifuCustomDataGrid1.DataSource = this.employeetableBindingSource1;
            this.bunifuCustomDataGrid1.DoubleBuffered = true;
            this.bunifuCustomDataGrid1.EnableHeadersVisualStyles = false;
            this.bunifuCustomDataGrid1.HeaderBgColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.bunifuCustomDataGrid1.HeaderForeColor = System.Drawing.Color.Lime;
            this.bunifuCustomDataGrid1.Location = new System.Drawing.Point(3, 149);
            this.bunifuCustomDataGrid1.Name = "bunifuCustomDataGrid1";
            this.bunifuCustomDataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.bunifuCustomDataGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bunifuCustomDataGrid1.Size = new System.Drawing.Size(868, 305);
            this.bunifuCustomDataGrid1.TabIndex = 0;
            this.bunifuCustomDataGrid1.DoubleClick += new System.EventHandler(this.bunifuCustomDataGrid1_DoubleClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Number";
            this.dataGridViewTextBoxColumn1.HeaderText = "Number";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "EmployeeİD";
            this.dataGridViewTextBoxColumn2.HeaderText = "EmployeeİD";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Firstname";
            this.dataGridViewTextBoxColumn3.HeaderText = "Firstname";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Lastname";
            this.dataGridViewTextBoxColumn4.HeaderText = "Lastname";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Date_Of_Birth";
            this.dataGridViewTextBoxColumn5.HeaderText = "Date_Of_Birth";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Telephone_Number";
            this.dataGridViewTextBoxColumn6.HeaderText = "Telephone_Number";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Email";
            this.dataGridViewTextBoxColumn7.HeaderText = "Email";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Sex";
            this.dataGridViewTextBoxColumn8.HeaderText = "Sex";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Civil_Status";
            this.dataGridViewTextBoxColumn9.HeaderText = "Civil_Status";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Position";
            this.dataGridViewTextBoxColumn10.HeaderText = "Position";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Department";
            this.dataGridViewTextBoxColumn11.HeaderText = "Department";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Work_Status";
            this.dataGridViewTextBoxColumn12.HeaderText = "Work_Status";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Date_Hired";
            this.dataGridViewTextBoxColumn13.HeaderText = "Date_Hired";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Pay_Methode";
            this.dataGridViewTextBoxColumn14.HeaderText = "Pay_Methode";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Daily_Rate";
            this.dataGridViewTextBoxColumn15.HeaderText = "Daily_Rate";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "_Address";
            this.dataGridViewTextBoxColumn16.HeaderText = "_Address";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // employeetableBindingSource1
            // 
            this.employeetableBindingSource1.DataMember = "Employee_table";
            this.employeetableBindingSource1.DataSource = this.hospitalManagmentSystDataSet5;
            // 
            // hospitalManagmentSystDataSet5
            // 
            this.hospitalManagmentSystDataSet5.DataSetName = "HospitalManagmentSystDataSet5";
            this.hospitalManagmentSystDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employee_tableTableAdapter
            // 
            this.employee_tableTableAdapter.ClearBeforeFill = true;
            // 
            // EmployeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(3)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(873, 586);
            this.Controls.Add(this.centralcotrolledpanel);
            this.Controls.Add(this.Dalete);
            this.Controls.Add(this.sendtodatabasebtn);
            this.Controls.Add(this.updatebtn);
            this.Controls.Add(this.viewempllistbtn);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EmployeeForm";
            this.Text = "EmployeeForm";
            this.Load += new System.EventHandler(this.EmployeeForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.centralcotrolledpanel.ResumeLayout(false);
            this.centralcotrolledpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchbtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeetableBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hospitalManagmentSystDataSet5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private System.Windows.Forms.GroupBox groupBox2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel12;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel16;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel15;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel17;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel14;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel13;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private System.Windows.Forms.TextBox addresstextbox;
        private Bunifu.Framework.UI.BunifuDatepicker birthdatepicker;
        private Bunifu.Framework.UI.BunifuDropdown sexempldropbox;
        private Bunifu.Framework.UI.BunifuDropdown civilstatusdropbox;
        private Bunifu.Framework.UI.BunifuMaterialTextbox lastnameempltextbox;
        private Bunifu.Framework.UI.BunifuMaterialTextbox firstnameempltextbox;
        private Bunifu.Framework.UI.BunifuMaterialTextbox phonenumbertextbox;
        private Bunifu.Framework.UI.BunifuMaterialTextbox emailempltextbox;
        private Bunifu.Framework.UI.BunifuMaterialTextbox idempltextbox;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel18;
        private Bunifu.Framework.UI.BunifuDropdown paymethodetextbox;
        private Bunifu.Framework.UI.BunifuDatepicker hirededatepicker;
        private Bunifu.Framework.UI.BunifuDropdown workstatusdropbox;
        private Bunifu.Framework.UI.BunifuDropdown positionbtext;
        private Bunifu.Framework.UI.BunifuDropdown departmentdropbox;
        private Bunifu.Framework.UI.BunifuMaterialTextbox dailyratetextbox;
        private Bunifu.Framework.UI.BunifuFlatButton viewempllistbtn;
        private Bunifu.Framework.UI.BunifuFlatButton updatebtn;
        private Bunifu.Framework.UI.BunifuFlatButton Dalete;
        private Bunifu.Framework.UI.BunifuFlatButton sendtodatabasebtn;
        private System.Windows.Forms.Panel centralcotrolledpanel;
        private Bunifu.Framework.UI.BunifuFlatButton addnewemplbtn;
        private Bunifu.Framework.UI.BunifuImageButton searchbtn;
        private Bunifu.Framework.UI.BunifuMetroTextbox searchtextbox;
        private Bunifu.Framework.UI.BunifuCustomDataGrid bunifuCustomDataGrid1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel19;
        private HospitalManagmentSystDataSet5 hospitalManagmentSystDataSet5;
        private System.Windows.Forms.BindingSource employeetableBindingSource1;
        private HospitalManagmentSystDataSet5TableAdapters.Employee_tableTableAdapter employee_tableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel20;
    }
}